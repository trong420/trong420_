# ip_amba_ahb_ms_rtl
RTL design for the AMBA AHB protocol.

Following are the spec designs which are avialable in this repository:
  - AHB Master
  - AHB Slave
  - AHB Single Master Bus Interconnect ( Decoder & Mux )
