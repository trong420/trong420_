# Simulation Guide - AHB Decoder Mux
This is a how to guide on instantiating and using the soft IPs provided in this repo.
